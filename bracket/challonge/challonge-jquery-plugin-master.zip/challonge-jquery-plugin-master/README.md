# [Challonge jQuery Plugin](http://plugins.jquery.com/challonge/)

View the interactive demo at [http://challonge.com/api/documents/jquery](http://challonge.com/api/documents/jquery).

## Installation


* Download and install [jQuery](http://jquery.com/).
* Add the [Challonge jQuery Plugin file](https://raw.github.com/challonge/challonge-jquery-plugin/master/jquery.challonge.js) to your website.
* Embed a bracket in an element.
* Customize for your page! [View all option descriptions](http://challonge.com/module/instructions).
